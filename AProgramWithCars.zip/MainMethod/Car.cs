﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainMethod
{
    class Car : Vehicle
    {
        private const double airConConsumption = 0.9;

        public Car(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption + airConConsumption, tankCapacity)
        {
        }

        public override string GetName()
        {
            return "Car";
        }    
    }
}
