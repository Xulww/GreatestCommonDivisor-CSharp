﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainMethod
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            TankCapacity = tankCapacity;

            if (fuelQuantity > tankCapacity)
            {
                fuelQuantity = 0;
            }

            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;         
        }

        public double FuelQuantity { get; private set; }
        public double FuelConsumption { get; protected set; }
        public double TankCapacity { get; private set; }
        public abstract string GetName();

        public string Drive(double distance)
        {
            if (distance * FuelConsumption <= FuelQuantity)
            {
                FuelQuantity -= distance * FuelConsumption;
                return $"{GetName()} travelled {distance} km";
            }

            return $"{GetName()} needs refueling";
        }

        public virtual string Refuel(double liters)
        {
            if (liters <= 0)
            {
                return "Fuel must be a positive number";
            }

            if (FuelQuantity + liters > TankCapacity)
            {
                return $"Cannot fit {liters} fuel in the tank";
            }

            FuelQuantity += liters;

            return null;
        }

        public override string ToString()
        {
            return $"{GetName()}: {FuelQuantity:f2}";
        }
    }
}
