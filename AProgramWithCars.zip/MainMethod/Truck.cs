﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainMethod
{
    class Truck : Vehicle
    {
        private const double airConConsumption = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption + airConConsumption, tankCapacity)
        {
        }

        public override string GetName()
        {
            return "Truck";
        }

        public override string Refuel(double liters)
        {
            liters *= 0.95;
            return base.Refuel(liters);
        }
    }
}
