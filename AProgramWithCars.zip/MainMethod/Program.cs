﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> vehicles = CreateVehicles();

            ReadCommandsFromConsole(vehicles);
            PrintVehicleInfo(vehicles);                 

            Console.ReadLine();
        }

        private static void PrintVehicleInfo(List<Vehicle> vehicles)
        {
            foreach (var vehicle in vehicles)
            {
                Console.WriteLine(vehicle.ToString());
            }
        }

        private static void ReadCommandsFromConsole(List<Vehicle> vehicles)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                int index = -1;

                string[] commandTokens = Console.ReadLine().Split(' ');
                string commandType = commandTokens[0];
                string vehicleType = commandTokens[1];
                double value = double.Parse(commandTokens[2]);

                if (vehicleType == "Car")
                {
                    index = 0;
                }

                if (vehicleType == "Truck")
                {
                    index = 1;
                }

                if (vehicleType == "Car")
                {
                    index = 0;
                }
                else if (vehicleType == "Truck")
                {
                    index = 1;
                }
                else if (vehicleType == "Bus")
                {
                    index = 2;
                }
                else
                {
                    throw new Exception("Vehicle not found!");
                }

                Vehicle currentVehicle = vehicles[index];

                string output = null;

                if (commandType == "Drive")
                {
                    output = (currentVehicle.Drive(value));
                }
                else if (commandType == "Refuel")
                {
                    output = currentVehicle.Refuel(value);
                }
                else if (commandType == "DriveEmpty")
                {
                    if (index != 2)
                    {
                        throw new Exception("This vehicle is not a bus");
                    }

                    output = ((Bus)currentVehicle).DriveEmpty(value);
                }

                if (output != null) 
                {
                    Console.WriteLine(output);
                }
            }
        }

        private static List<Vehicle> CreateVehicles()
        {
            string[] carTokens = Console.ReadLine().Split(' ');

            double carFuelQuantity = double.Parse(carTokens[1]);
            double carFuelConsumption = double.Parse(carTokens[2]);
            double carTankCapacity = double.Parse(carTokens[3]);

            Car c1 = new Car(carFuelQuantity, carFuelConsumption, carTankCapacity);

            string[] truckTokens = Console.ReadLine().Split(' ');

            double truckFuelQuantity = double.Parse(truckTokens[1]);
            double truckFuelConsumption = double.Parse(truckTokens[2]);
            double truckTankCapacity = double.Parse(truckTokens[3]);

            Truck t1 = new Truck(truckFuelQuantity, truckFuelConsumption, truckTankCapacity);

            string[] busTokens = Console.ReadLine().Split(' ');

            double busFuelQuantity = double.Parse(busTokens[1]);
            double busFuelConsumption = double.Parse(busTokens[2]);
            double busTankCapacity = double.Parse(busTokens[3]);

            Bus b1 = new Bus(busFuelQuantity, busFuelConsumption, busTankCapacity);


            return new List<Vehicle>()
            {
                c1,
                t1,
                b1
            };
        }
    }
}
