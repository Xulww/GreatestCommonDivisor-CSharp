﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainMethod
{
    class Bus : Vehicle
    {
        private const double airConConsumption = 1.4;

        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption + airConConsumption, tankCapacity)
        {          
        }

        public override string GetName()
        {
            return "Bus";
        }

        public string DriveEmpty(double distance)
        {
            FuelConsumption -= airConConsumption;

            string result = base.Drive(distance);

            FuelConsumption += airConConsumption;

            return result;
        }
    }
}
